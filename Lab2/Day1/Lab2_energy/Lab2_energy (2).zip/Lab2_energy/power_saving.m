function p_sav=power_saving(p_old,p_new)
p_sav=p_old-p_new/p_old*100;
end