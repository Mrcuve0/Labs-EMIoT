function I_lin=t_lin(I,alpha)
I_lin=[];
I_lin=I*alpha;
end