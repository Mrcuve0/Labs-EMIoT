function perc=percdist(eps,n,m)

perc=(eps/(n*m*sqrt(100^2+255^2+255^2)))*100;

end