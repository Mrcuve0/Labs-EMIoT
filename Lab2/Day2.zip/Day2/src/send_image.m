function send_image(file_pointer, img_R, img_G, img_B)
    n = size(img_R);
    
%     fwrite(file_pointer,['0','1',img_B(1, :)],'unsigned char');
%     fwrite(file_pointer,['0','1',img_G(1, :)],'unsigned char');
%     fwrite(file_pointer,['0','1',img_R(1, :)],'unsigned char');
    writeline(file_pointer, ['0','1',img_B(1, :)])
    writeline(file_pointer, ['0','1',img_G(1, :)])
    writeline(file_pointer, ['0','1',img_R(1, :)])
    
    for i = 2:n
%         fwrite(file_pointer,['0','0',img_B(i, :)],'unsigned char');
%         fwrite(file_pointer,['0','0',img_G(i, :)],'unsigned char');
%         fwrite(file_pointer,['0','0',img_R(i, :)],'unsigned char');
        writeline(file_pointer, ['0','1',img_B(i, :)])
        writeline(file_pointer, ['0','1',img_G(i, :)])
        writeline(file_pointer, ['0','1',img_R(i, :)])
    end
end