clear all
close all
clc
format long

if ~isempty(instrfind)
    fclose(instrfind);
    delete(instrfind);
end

img_index = 1;

% Image manipulation
img_8bit_dec = imread("../images/img_" + num2str(img_index) + ".tiff");

% Form RGB representation to BGR representation
R_8bit = img_8bit_dec(:,:,1);    
G_8bit = img_8bit_dec(:,:,2);
B_8bit = img_8bit_dec(:,:,3);
img_8bit_dec(:,:,1) = B_8bit;
img_8bit_dec(:,:,2) = G_8bit;
img_8bit_dec(:,:,3) = R_8bit;

% Shift from a 8 bit representation to a 6 bit representation
img_8bit_bin_B = dec2bin(bitshift(img_8bit_dec(:,:,1), -2));
img_8bit_bin_G = dec2bin(bitshift(img_8bit_dec(:,:,2), -2));
img_8bit_bin_R = dec2bin(bitshift(img_8bit_dec(:,:,2), -2));

% Serial connection
% serCon = serial('/dev/tty.usbmodem14501', 'BaudRate', 115200);

% file = fopen('./sticazzi.txt','w');
port = '/dev/ttyACM0';
baudRate = 115200;
dataBits = 8;
stopBits = 1;
parity = 'none';
% file = serialport('Port', port, 115200, 'DataBits', dataBits, 'StopBits', stopBits, 'Parity', parity);
file = serialport("/dev/ttyACM0", 115200, 'DataBits', dataBits, 'StopBits', stopBits, 'Parity', parity);

% fopen(file);
pause(4);

send_image(file, img_8bit_bin_R, img_8bit_bin_G, img_8bit_bin_B)

% fclose(serCon);